# Zain Free VPN — prototype

This repository is a **working VPN-client/API prototype**, not a promise of free mobile data. It connects to a WireGuard server using a configuration provisioned by the backend. A VPN normally still uses the carrier's data allowance. Free/zero-rated access requires a written Zain Sudan agreement and carrier-side network configuration.

## Architecture

- `android/`: Kotlin Android app (Android 11/API 30+), WireGuard tunnel library, connect/disconnect, server list, status and traffic counters.
- `backend/`: FastAPI service for server listing, authenticated configuration provisioning, diagnostics and health checks.
- `deploy/`: example server setup notes and deployment guidance.

## Project structure

```text
ZainFreeVPN/
├── android/
│   ├── settings.gradle.kts
│   ├── build.gradle.kts
│   └── app/
│       ├── build.gradle.kts
│       └── src/main/
│           ├── AndroidManifest.xml
│           ├── java/com/zainfreevpn/
│           │   ├── MainActivity.kt
│           │   ├── ApiClient.kt
│           │   └── VpnController.kt
│           └── res/values/strings.xml
├── backend/
│   ├── main.py
│   ├── requirements.txt
│   ├── Dockerfile
│   └── .env.example
└── deploy/
    └── wireguard-server.md
```

## Quick start

1. Install Android Studio (current stable), open the `android/` folder, and allow Gradle sync.
2. Start the backend locally: `cd backend`, create a virtual environment, install `requirements.txt`, set `ADMIN_TOKEN` and `DEMO_WG_CONFIG`, then run `uvicorn main:app --host 0.0.0.0 --port 8080`.
3. For a real phone, use a reachable HTTPS backend URL. Do not expose the development server directly to the public internet.
4. Configure the backend with a valid *client* WireGuard configuration. The corresponding peer must already exist on your WireGuard server.
5. Run the Android app, grant the Android VPN permission, select a server, and connect.

The included demo configuration is deliberately not a working public tunnel. Replace it with a real peer configuration generated for your server. Do not commit private keys to source control.

## Authentication and production hardening

The sample API uses bearer-token authentication to make the prototype testable. It is **not production identity management**: do not ship a shared bearer token inside an APK. Replace it with individual account/device authentication (OIDC or short-lived, device-bound tokens), TLS, rate limits, revocation, audit logs, secret-manager storage and abuse controls. Keep WireGuard private keys server-side where possible; per-device client private keys should be generated on-device and only public keys sent to provisioning.

## Sponsored data / free internet

No app-side setting can make Zain data free. A legitimate implementation requires Zain Sudan to approve a sponsored-data/zero-rating arrangement, identify eligible endpoints and traffic, and apply the relevant billing policy on its network. Ask Zain for its enterprise/A2P/zero-rating process and technical requirements. Until the agreement is live and verified on a Zain SIM, show the notice that normal data charges may apply.

## Current prototype scope

Implemented: native Android shell, WireGuard tunnel API integration, server list, connect/disconnect, backend health/config endpoints, diagnostics endpoint, simple upload/download counters, English/Arabic strings starter.

Not implemented/production-ready: user registration, secure device enrollment, automated key lifecycle, actual carrier-sponsored billing, multi-region orchestration, robust background service UX, formal penetration test, Play policy review, complete RTL/localization and end-to-end test results. The app reports traffic from Android's process/network counters where available; these are estimates, not carrier billing records.
