import os, time, secrets
from typing import Optional
from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel

app = FastAPI(title="Zain Free VPN API", version="0.1.0")
ADMIN_TOKEN = os.getenv("ADMIN_TOKEN", "")
WG_CONFIG = os.getenv("DEMO_WG_CONFIG", "")
STARTED = time.time()
# Prototype in-memory limiter. Use Redis/API gateway rate limits in production.
hits: dict[str, list[float]] = {}
SERVERS = [
    {"id": "demo-eu-1", "name": "Europe • Demo", "endpoint": "", "healthy": bool(WG_CONFIG)}
]

def authorize(authorization: Optional[str]):
    if not ADMIN_TOKEN:
        raise HTTPException(503, "API authentication is not configured")
    expected = "Bearer " + ADMIN_TOKEN
    if not authorization or not secrets.compare_digest(authorization, expected):
        raise HTTPException(401, "Authentication required")

@app.middleware("http")
async def basic_rate_limit(request: Request, call_next):
    ip = request.client.host if request.client else "unknown"
    now = time.time()
    bucket = [t for t in hits.get(ip, []) if now - t < 60]
    if len(bucket) >= 60:
        return JSONResponse(status_code=429, content={"detail": "Rate limit exceeded"})
    bucket.append(now); hits[ip] = bucket
    return await call_next(request)

@app.get("/health")
def health():
    return {"status": "ok", "uptime_seconds": int(time.time() - STARTED)}

@app.get("/v1/servers")
def servers(authorization: Optional[str] = Header(default=None)):
    authorize(authorization)
    return {"servers": SERVERS}

@app.get("/v1/config")
def config(server_id: str, authorization: Optional[str] = Header(default=None)):
    authorize(authorization)
    if not any(s["id"] == server_id for s in SERVERS):
        raise HTTPException(404, "Unknown server")
    if not WG_CONFIG.strip() or "[Interface]" not in WG_CONFIG or "[Peer]" not in WG_CONFIG:
        raise HTTPException(503, "No valid WireGuard client configuration has been provisioned")
    return {"server_id": server_id, "wireguard_config": WG_CONFIG,
            "notice": "Carrier data charges may apply; sponsored data is not verified."}

class DiagnosticRequest(BaseModel):
    server_id: Optional[str] = None
    client_version: Optional[str] = None
    network: Optional[str] = None

@app.get("/v1/diagnostics")
def diagnostics(authorization: Optional[str] = Header(default=None)):
    authorize(authorization)
    return {"api": "ok", "wireguard_configured": bool(WG_CONFIG.strip()),
            "sponsored_data": "unverified", "uptime_seconds": int(time.time()-STARTED)}

@app.post("/v1/diagnostics")
def post_diagnostics(payload: DiagnosticRequest, authorization: Optional[str] = Header(default=None)):
    authorize(authorization)
    # Do not log subscriber identifiers or sensitive network data.
    return {"received": True, "server_id": payload.server_id, "timestamp": int(time.time()),
            "message": "API reachable; tunnel health must be verified on device."}
