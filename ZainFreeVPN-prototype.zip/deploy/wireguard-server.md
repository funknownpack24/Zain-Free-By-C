# WireGuard server deployment notes

Use a reputable VPS provider and a supported Linux distribution. The VPN server needs a public IPv4/IPv6 endpoint, UDP port (commonly 51820), IP forwarding, firewall/NAT rules, DNS resolvers, monitoring and patching.

## High-level setup

1. Provision a small Linux VPS in a region legally appropriate for your users.
2. Install WireGuard from the distribution's official packages.
3. Generate server keys on the server and store private keys with restrictive permissions (`chmod 600`).
4. Create a unique peer per device. Assign a unique tunnel address and use a client config with `PrivateKey`, `Address`, `DNS`, and a `[Peer]` section containing the server public key, endpoint, and allowed IPs.
5. Enable IPv4 forwarding and configure firewall/NAT for the chosen tunnel subnet. Add IPv6 forwarding/firewall rules only if the server is correctly configured for IPv6; otherwise block IPv6 inside the tunnel to prevent leaks.
6. Verify handshake, DNS, IPv4 and IPv6 behavior, MTU and reconnects. Monitor server health and abuse.
7. Put the client config in a protected secret store and provision it only to its intended authenticated device. The prototype's shared-config endpoint is for controlled development only.

Never place the server private key in the app or backend API response. Never reuse a single client private key across all users. The included prototype API does not yet implement per-device key generation/revocation, so it is not ready for public production use.

## Carrier-sponsored data

Work directly with Zain Sudan's authorized enterprise/network team. Ask for their zero-rating or sponsored-data process, eligible destination/IP/port requirements, traffic accounting and reporting, security review, contract and test SIM procedure. Do not try to disguise traffic or exploit billing exceptions. A normal encrypted VPN tunnel is generally billed as ordinary data unless the carrier has explicitly configured and approved a sponsored arrangement.
