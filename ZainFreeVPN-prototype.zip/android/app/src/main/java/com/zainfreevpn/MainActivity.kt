package com.zainfreevpn

import android.app.Activity
import android.net.VpnService
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.wireguard.android.backend.Tunnel
import kotlinx.coroutines.*

class MainActivity : AppCompatActivity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var api: ApiClient
    private lateinit var vpn: VpnController
    private lateinit var status: TextView
    private lateinit var serverPicker: Spinner
    private lateinit var connect: Button
    private lateinit var log: TextView
    private var servers: List<VpnServer> = emptyList()
    private var connected = false
    private val requestVpn = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        api = ApiClient()
        vpn = VpnController(this)
        buildUi()
        loadServers()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(23, 19, 27))
        }
        fun text(value: String, size: Float, color: Int = Color.WHITE) =
            TextView(this).apply { text = value; textSize = size; setTextColor(color); gravity = Gravity.CENTER }
        root.addView(text("ZAIN FREE VPN", 24f, Color.rgb(244, 95, 164)))
        root.addView(text("Secure connection • Sudan", 14f, Color.LTGRAY))
        status = text("Disconnected", 18f)
        val statusParams = LinearLayout.LayoutParams(-1, 100).apply { topMargin = 18 }
        root.addView(status, statusParams)
        serverPicker = Spinner(this)
        root.addView(serverPicker, LinearLayout.LayoutParams(-1, 54))
        connect = Button(this).apply {
            text = "CONNECT"
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(232, 62, 140)))
            setOnClickListener { if (connected) disconnect() else requestPermissionAndConnect() }
        }
        root.addView(connect, LinearLayout.LayoutParams(-1, 60).apply { topMargin = 16 })
        root.addView(text("Free data is not guaranteed. Normal Zain data charges may apply unless an authorized sponsored-data agreement is active.", 12f, Color.LTGRAY),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = 20 })
        log = text("Ready.", 12f, Color.LTGRAY).apply { gravity = Gravity.START }
        root.addView(log, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = 20 })
        setContentView(root)
    }

    private fun loadServers() = scope.launch {
        try {
            servers = api.servers()
            serverPicker.adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                servers.map { "${it.name} ${if (it.healthy) "• Online" else "• Offline"}" })
            if (servers.isEmpty()) log.text = "No VPN servers configured in the backend."
        } catch (e: Exception) {
            log.text = "Server list unavailable: ${e.message ?: "check API URL and network"}"
        }
    }

    private fun requestPermissionAndConnect() {
        val intent = VpnService.prepare(this)
        if (intent != null) startActivityForResult(intent, requestVpn) else connectNow()
    }

    @Deprecated("Android callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestVpn && resultCode == Activity.RESULT_OK) connectNow()
    }

    private fun connectNow() = scope.launch {
        if (servers.isEmpty()) { log.text = "No server available. Check backend configuration."; return@launch }
        connect.isEnabled = false
        status.text = "Connecting…"
        try {
            val server = servers[serverPicker.selectedItemPosition.coerceIn(0, servers.lastIndex)]
            val config = withContext(Dispatchers.IO) { api.config(server.id) }
            withContext(Dispatchers.IO) { vpn.connect(config) }
            connected = true
            connect.text = "DISCONNECT"
            status.text = "Connected • ${server.name}"
            log.text = "WireGuard tunnel requested successfully. Verify browsing and DNS before relying on it."
        } catch (e: Exception) {
            connected = false
            status.text = "Connection failed"
            log.text = "Could not connect: ${e.message ?: "unknown error"}"
        } finally { connect.isEnabled = true }
    }

    private fun disconnect() {
        scope.launch {
            try { withContext(Dispatchers.IO) { vpn.disconnect() } }
            catch (e: Exception) { log.text = "Disconnect warning: ${e.message}" }
            connected = false
            connect.text = "CONNECT"
            status.text = "Disconnected"
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
