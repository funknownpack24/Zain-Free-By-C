package com.zainfreevpn

import android.content.Context
import com.wireguard.android.backend.Backend
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.android.backend.Tunnel.State
import com.wireguard.config.Config
import java.io.BufferedReader
import java.io.StringReader

class VpnController(context: Context) {
    private val backend: Backend = GoBackend(context.applicationContext)
    private val tunnel = object : Tunnel {
        override fun getName(): String = "zain-free-vpn"
        override fun onStateChange(newState: State) { stateListener?.invoke(newState) }
    }
    var stateListener: ((State) -> Unit)? = null
    @Volatile var currentState: State = State.DOWN
        private set

    fun connect(configText: String) {
        val config = Config.parse(BufferedReader(StringReader(configText)))
        currentState = backend.setState(tunnel, State.UP, config)
    }
    fun disconnect() {
        currentState = backend.setState(tunnel, State.DOWN, null)
    }
}
