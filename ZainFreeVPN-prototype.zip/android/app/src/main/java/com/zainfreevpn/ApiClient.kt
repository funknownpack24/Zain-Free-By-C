package com.zainfreevpn

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class VpnServer(val id: String, val name: String, val endpoint: String, val healthy: Boolean)

class ApiClient(
    private val baseUrl: String = BuildConfig.API_BASE_URL,
    private val token: String = BuildConfig.API_TOKEN
) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .build()

    private suspend fun get(path: String): String = withContext(Dispatchers.IO) {
        val request = Request.Builder().url(baseUrl.trimEnd('/') + path)
            .header("Authorization", "Bearer $token").get().build()
        http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("API returned HTTP ${response.code}")
            response.body?.string() ?: error("Empty API response")
        }
    }

    suspend fun servers(): List<VpnServer> {
        val array = JSONObject(get("/v1/servers")).getJSONArray("servers")
        return (0 until array.length()).map { i ->
            val item = array.getJSONObject(i)
            VpnServer(item.getString("id"), item.getString("name"),
                item.optString("endpoint", ""), item.optBoolean("healthy", false))
        }
    }

    suspend fun config(serverId: String): String {
        val url = "/v1/config?server_id=" + java.net.URLEncoder.encode(serverId, "UTF-8")
        return JSONObject(get(url)).getString("wireguard_config")
    }

    suspend fun diagnostics(): String = get("/v1/diagnostics")
}
